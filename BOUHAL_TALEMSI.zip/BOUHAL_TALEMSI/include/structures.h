/* -*- c-basic-offset: 3 -*-
 *
 * ENSICAEN
 * 6 Boulevard Marechal Juin
 * F-14050 Caen Cedex
 *
 * This file is owned by ENSICAEN students.
 * 
 */

/**
 * @author BOUHAL Mohamed <mohamed.bouhal@ecole.ensicaen.fr>
 * @author TALEMSI Saad <saad.talemsi@ecole.ensicaen.fr>
 * @version 1.0.0 / 23-05-2024
 */

/**
 * @file structures.h
 * @brief Definitions of various structures used in the racing simulation project.
 */

#ifndef STRUCTURES_H
#define STRUCTURES_H

#define MAX 300000000 // a modifier

/**
 * @brief Represents a position and a speed in the track.
 */
typedef struct Tile {
    int x;  /** The x-coordinate of the tile. */
    int y;  /** The y-coordinate of the tile. */
    int vx; /** The x-component of the velocity. */
    int vy; /** The y-component of the velocity. */
} Tile;

/**
 * @brief Node structure for the linked list used in the queue.
 */
typedef struct nodeQueue {
    Tile newData;           /** The data held by the node. */
    struct nodeQueue* nextNode; /** A pointer to the next node in the list. */
} NodeQueue;

/**
 * @brief Queue structure based on a linked list.
 */
typedef struct queue {
    NodeQueue* frontNode;  /** A pointer to the front (first) element in the queue. */
    NodeQueue* rearNode;   /** A pointer to the rear (last) element in the queue. */
    int queueSize;         /** The number of elements in the queue. */
} Queue;

/**
 * @brief Represents a section of the racing track.
 */
typedef struct trackSection {
    int sectionWidth;       /** The width of the track section. */
    int sectionHeight;      /** The height of the track section. */
    int fuelAmount;         /** The amount of fuel available in this section. */
    char **trackData;       /** A 2D array representing the track layout. */
} *TrackSection;

/**
 * @brief Represents a state in the racing simulation.
 */
typedef struct Cell {
    Tile cellLocation;      /** The location (position and velocity) of the cell. */
    int cellAccelerationX;  /** The x-component of the acceleration applied to reach this cell. */
    int cellAccelerationY;  /** The y-component of the acceleration applied to reach this cell. */
    int cellFuel;           /** The amount of fuel used to reach this cell. */
    char cellType;          /** The type of the cell (e.g., track, obstacle). */
    struct Cell *nextCell;  /** A pointer to the next cell in the adjacency list. */
} Cell;

/**
 * @brief Represents a node in the adjacency list.
 */
typedef struct Node {
    Cell* nextCell;         /** A pointer to the first outgoing cell (adjacent node). */
    Cell* previousCell;     /** A pointer to the previous cell in the adjacency list. */
    Cell* dijNextCell;      /** A pointer to the next cell in Dijkstra's pathfinding. */
    Cell* dijPreviousCell;  /** A pointer to the previous cell in Dijkstra's pathfinding. */
    int nodeTag;            /** A tag used for marking the node (e.g., visited, unvisited). */
    int nodeDistance;       /** The distance from the starting node. */
    int nodeTotalWeight;    /** The total weight (cost) to reach this node. */
    int nodeTotalFuel;      /** The total fuel used to reach this node. */
} Node;

/**
 * @brief Represents the entire graph of the track.
 */
typedef struct graph {
    int listHeight;         /** The height of the adjacency list (number of rows in the track). */
    int listWidth;          /** The width of the adjacency list (number of columns in the track). */
    int numArcs;            /** The number of arcs (connections) in the graph. */
    int numNodes;           /** The number of nodes in the graph. */
    Node* ****nodeList;     /** A 5D array of pointers to nodes (organized by x, y, vx, and vy). */
    Tile startingPoints[3]; /** An array of starting points for the cars. */
    Tile finishPoints[MAX]; /** An array of finish points on the track. */
    int numFinishPoints;    /** The number of finish points in the graph. */
} graph;

/**
 * @brief Represents a node in a binary search tree.
 */
typedef struct binarySearchTree {
    Tile nodeValue;              /** The value (tile) held by this node. */
    struct binarySearchTree *leftNode;  /** A pointer to the left child node. */
    struct binarySearchTree *rightNode; /** A pointer to the right child node. */
    int nodeWeight;             /** The weight associated with this node (used in pathfinding). */
} bst;

#endif /* STRUCTURES_H */

