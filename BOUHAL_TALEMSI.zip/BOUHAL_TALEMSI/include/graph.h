/* -*- c-basic-offset: 3 -*-
 *
 * ENSICAEN
 * 6 Boulevard Marechal Juin
 * F-14050 Caen Cedex
 *
 * This file is owned by ENSICAEN students.
 * 
 */

/**
 * @author BOUHAL Mohamed <mohamed.bouhal@ecole.ensicaen.fr>
 * @author TALEMSI Saad <saad.talemsi@ecole.ensicaen.fr>
 * @version 1.0.0 / 23-05-2024
 */

/**
 * @file graph.h
 * @brief Header file for graph-related functions and structures.
 */

#ifndef GRAPH_H
#define GRAPH_H

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "queue.h"
#include "bst.h"
#include "structures.h"

/**
 * @brief Initializes an adjacency list for the track.
 * 
 * @param t The track section to be converted into an adjacency list.
 * @return A pointer to the initialized graph.
 */
graph* initgraph(TrackSection t);

/**
 * @brief Frees the memory allocated for the adjacency list.
 * 
 * @param L The adjacency list to be freed.
 * @param T The track section associated with the adjacency list.
 */
void freegraph(graph* L, TrackSection T);

/**
 * @brief Creates a new Node.
 * 
 * @return A pointer to the newly created Node.
 */
Node* createNode();

/**
 * @brief Creates a new Cell object.
 * 
 * @param head The location of the cell.
 * @param fuel The amount of fuel used to reach this cell.
 * @param ax The x-component of acceleration.
 * @param ay The y-component of acceleration.
 * @param next A pointer to the next cell in the adjacency list.
 * @return A pointer to the newly created Cell.
 */
Cell *createCell(Tile head, int fuel, int ax, int ay, Cell* next);

/**
 * @brief Frees the memory allocated to a Cell.
 * 
 * @param c The Cell to be freed.
 */
void freeCells(Cell *c);

/**
 * @brief Checks if a given tile is within the track.
 * 
 * @param p The tile to be checked.
 * @param L The graph representing the track.
 * @return 1 if the tile is within the track, 0 otherwise.
 */
int TileInTrack(Tile p, graph* L);

/**
 * @brief Checks if a given point on the track matches a specific character.
 * 
 * @param t The track section to be checked.
 * @param p The tile to be checked.
 * @param c The character to compare against.
 * @return 1 if the tile matches the character, 0 otherwise.
 */
int testPoint(TrackSection t, Tile p, char c);

/**
 * @brief Checks if the path between two points on the track is clear.
 * 
 * @param track The track section containing the points.
 * @param startTile The starting point of the path.
 * @param endTile The ending point of the path.
 * @return 1 if the path is clear, 0 otherwise.
 */
int isPathClear(TrackSection track, Tile startTile, Tile endTile);

/**
 * @brief Finds the shortest path in the graph using Dijkstra's algorithm.
 * 
 * @param network The graph representing the track.
 * @param trackSection The track section being processed.
 * @param startTile The starting tile for the pathfinding.
 * @param weightFactor The factor used to calculate the weight of the edges.
 * @return The tile representing the end of the shortest path.
 */
Tile dijkstra(graph *network, TrackSection trackSection, Tile startTile, float weightFactor);

#endif /* GRAPH_H */

