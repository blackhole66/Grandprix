/* -*- c-basic-offset: 3 -*-
 *
 * ENSICAEN
 * 6 Boulevard Marechal Juin
 * F-14050 Caen Cedex
 *
 * This file is owned by ENSICAEN students.
 * 
 */

/**
 * @author BOUHAL Mohamed <mohamed.bouhal@ecole.ensicaen.fr>
 * @author TALEMSI Saad <saad.talemsi@ecole.ensicaen.fr>
 * @version 1.0.0 / 23-05-2024
 */

/**
 * @file queue.h
 * @brief Header file for the linked list based queue implementation.
 */

#ifndef QUEUE_H_
#define QUEUE_H_

#include <stdlib.h>
#include "structures.h"

/**
 * @brief Creates a new, empty queue.
 *
 * @return A pointer to the newly created queue.
 */
Queue* createQueue();

/**
 * @brief Adds an element to the rear of the queue.
 *
 * @param q A pointer to the queue to add the element to.
 * @param data The data to be added to the queue.
 * @param mode The mode of the enqueue operation.
 */
void enqueue(Queue* q, Tile data, int mode);

/**
 * @brief Removes and returns the front element of the queue.
 *
 * @param q A pointer to the queue to remove the front element from.
 * @return The data stored in the front element of the queue.
 */
Tile dequeue(Queue* q);

/**
 * @brief Checks whether the queue is empty.
 *
 * @param q The queue to check.
 * @return 1 if the queue is empty, 0 otherwise.
 */
int isQueueEmpty(Queue* q);

#endif 

