/* -*- c-./include/basic-offset: 3 -*-
 *
 * ENSICAEN
 * 6 Boulevard Marechal Juin
 * F-14050 Caen Cedex
 *
 * This file is owned by ENSICAEN students.
 * 
 */

/**
 * @author BOUHAL mohamed <mohamed.bouhal@ecole.ensicaen.fr>
 * @author TALEMSI saad   <saad.talemsi@ecole.ensicaen.fr>
 * @version 1.0.0 / 23-05-2024
 */
#ifndef BST_H_INCLUDED
#define BST_H_INCLUDED
#include "structures.h"


/**
 * @brief A node in a binary search tree.
 */


/**
 * @brief A binary search tree is a pointer to the root node.
 */
typedef bst *BinarySearchTree;


/**
 * @brief Create an empty binary search tree.
 * @return A pointer to the root of the new empty tree (NULL pointer).
 */
BinarySearchTree createEmptyBST() ;

/**
 * @brief Free the memory of a binary search tree.
 * @param tree Pointer to the root of the tree.
 */
void freeBST(BinarySearchTree tree);

/**
 * @brief Add a value to a binary search tree.
 * @param tree Pointer to the root of the tree.
 * @param value The value to add.
 * @return A pointer to the root of the modified tree.
 */
BinarySearchTree addToBST(BinarySearchTree tree, int x, Tile data);




/**
 * @brief push a node in a binary search tree.
 * @param tree Pointer to the root of the tree.
 * @param data The value to add.
*/
bst* popMin(bst* tree, Tile *data);


#endif // BST_H_INCLUDED

