#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "structures.h"
#include "queue.h"

NodeQueue* createNodeQueue(Tile newData, NodeQueue* nextNode) {
    NodeQueue* node = (NodeQueue*)malloc(sizeof(NodeQueue));
    node->newData = newData;
    node->nextNode = nextNode;
    return node;
}

/**
 * @brief Creates a new, empty queue.
 *
 * @return A pointer to the newly created queue.
 */
Queue* createQueue() {
    Queue* queue = (Queue*)malloc(sizeof(Queue));
    queue->frontNode = NULL;
    queue->rearNode = NULL;
    queue->queueSize = 0;
    return queue;
}

/**
 * @brief Adds an element to the rearNode of the queue.
 *
 * @param queue A pointer to the queue to add the element to.
 * @param newData The data to be added to the queue.
 * @param mode Mode determines where to add the new element (frontNode or rearNode).
 */
void enqueue(Queue* q, Tile data, int mode) { 
    if (q == NULL) return;
    if (isQueueEmpty(q)) {
        q->frontNode = createNodeQueue(data, NULL);
        q->rearNode = q->frontNode;
    } else if (mode == 0) {
        NodeQueue* n = createNodeQueue(data, NULL);
        n->nextNode = q->frontNode;
        q->frontNode = n;
    } else if (mode == 1) {
        NodeQueue* n = createNodeQueue(data, NULL);
        q->rearNode->nextNode = n;
        q->rearNode = n;
    }
    q->queueSize++;
}


/**
 * @brief Removes and returns the frontNode element of the queue.
 *
 * @param queue A pointer to the queue to remove the frontNode element from.
 * @return The data stored in the frontNode element of the queue.
 */
Tile dequeue(Queue* q) {
    NodeQueue* temp = q->frontNode;
    if (temp->nextNode != NULL) {
        q->frontNode = temp->nextNode;
    } else {
        q->frontNode = NULL;
        q->rearNode = NULL;
    }
    Tile data = temp->newData;
    free(temp);
    q->queueSize--;
    return data;
}

/**
 * @brief Checks whether the queue is empty.
 *
 * @param queue The queue to check.
 * @return 1 if the queue is empty, 0 otherwise.
 */
int isQueueEmpty(Queue* queue) {
    return (queue->frontNode == NULL) ? 1 : 0;
}

