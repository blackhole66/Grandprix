/**
 * \file bst.c
 * \brief Implementation of classical functions for BST
 * \author Loïck LHOTE
 * \version 0.1
 * \date janvier 2023
 *
 * Source code of the functions declared in bst.h.
 * Thes functions are to manipulate binary search trees.
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "bst.h"


/**
 * @brief Create an empty binary search tree.
 * @return A pointer to the root of the new empty tree (NULL pointer).
 */
BinarySearchTree createEmptyBST() {
    return NULL;
}

/**
 * @brief Free the memory of a binary search tree.
 * @param tree Pointer to the root of the tree.
 */
void freeBST(BinarySearchTree tree) {
    free(tree);
    return;
}


/**
 * @brief Add a value to a binary search tree.
 * @param tree Pointer to the root of the tree.
 * @param value The value to add.
 * @return A pointer to the root of the modified tree.
 */

BinarySearchTree addToBST(bst *tree, int x, Tile data) {
    if (tree == NULL) {
        tree = malloc(sizeof(bst));
        tree->nodeWeight = x;
        tree->nodeValue = data;
        tree->leftNode = NULL;
        tree->rightNode = NULL;
    } else if (x < tree->nodeWeight) {
        tree->leftNode = addToBST(tree->leftNode, x, data);
    } else {
        tree->rightNode = addToBST(tree->rightNode, x, data);
    }
    return tree;
}






bst* popMin(bst* tree, Tile *data) {
    bst* new;
    if (tree->leftNode == NULL) {
        new = tree;
        *data = tree->nodeValue;
        tree = tree->rightNode;
        free(new);
    }
    else {
        tree->leftNode = popMin(tree->leftNode, data);
    }
    return tree;
}








