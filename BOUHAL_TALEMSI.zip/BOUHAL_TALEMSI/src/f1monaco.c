/* -*- c-basic-offset: 3 -*-
 *
 * ENSICAEN
 * 6 Boulevard Marechal Juin
 * F-14050 Caen Cedex
 *
 * This file is owned by ENSICAEN students.
 * 
 */

/**
 * @author BOUHAL Mohamed <mohamed.bouhal@ecole.ensicaen.fr>
 * @author TALEMSI Saad <saad.talemsi@ecole.ensicaen.fr>
 * @version 1.0.0 / 23-05-2024
 */

/**
 * @file LesCaentastrophiques.c
 */

#include <bits/time.h>
#include <time.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "graph.h"
#include "structures.h"
#include "queue.h"

/**
 * @brief Calculate the fuel cost of an acceleration.
 * 
 * Cette fonction calcule le coût en carburant d'une accélération donnée.
 * Le coût est basé sur les composants x et y de l'accélération, la vitesse actuelle,
 * et une pénalité pour rouler sur du sable.
 * 
 * @param accX The x-component of the acceleration.
 * @param accY The y-component of the acceleration.
 * @param velX The x-component of the velocity.
 * @param velY The y-component of the velocity.
 * @param sand The penalty for being on sand.
 * @return The negative fuel cost.
 */
int calculateFuelCost(int accX, int accY, int velX, int velY, int sand) {
    int cost = accX * accX + accY * accY; // Coût de base basé sur les composants de l'accélération
    cost += (int)(sqrt(velX * velX + velY * velY) * 3.0 / 2.0); // Coût additionnel basé sur la vitesse
    cost += sand; // Ajouter la pénalité pour rouler sur du sable, si applicable
    return -cost; // Retourner le coût négatif
}

/**
 * @brief Send the acceleration command.
 * 
 * Cette fonction envoie la commande d'accélération au simulateur.
 * 
 * @param accX The x-component of the acceleration.
 * @param accY The y-component of the acceleration.
 */
void sendAccelerationCommand(int accX, int accY) {
    char command[10]; // Buffer pour stocker la commande
    sprintf(command, "%d %d", accX, accY); // Formater la commande
    fprintf(stdout, "%s\n", command); // Envoyer la commande au simulateur
    fflush(stdout); // Vider le tampon de sortie pour s'assurer que la commande est envoyée immédiatement
}

int main() {
    // Initialisation des variables de contrôle et de l'état de la course
    int fuelReductionFlag = 0, fuelIncreaseFlag = 0, lapCounter = 0, collisionFlag = 1;
    int result, accX, accY, remainingFuel, isBlocked;
    float lowerBound = 0, upperBound = 10, weightFactor = 2.5;
    char backupCharB, backupCharC;
    float lowerThreshold = 0.97f;
    float upperThreshold = 0.93f;
    Tile startTile, nextTile, obstacleB, obstacleC, targetTile;
    Queue *pathQueue = NULL;
    graph *adjList = NULL;

    // Initialiser la structure de la piste
    TrackSection track = malloc(sizeof(struct trackSection));
    if (track == NULL) {
        exit(1); // Quitter si l'allocation de mémoire échoue
    }

    char tempChar;
    int fscanfResult;

    // Lire les dimensions et la quantité de carburant depuis le fichier d'entrée
    fscanfResult = fscanf(stdin, "%d %d %d", &(track->sectionWidth), &(track->sectionHeight), &(track->fuelAmount));
    fscanfResult = fscanfResult; // Éviter l'avertissement de variable inutilisée
    if (track->sectionHeight == 0 || track->sectionWidth == 0 || track->fuelAmount == 0) {
        exit(1); // Quitter si des informations critiques sur la piste sont manquantes ou nulles
    }

    // Sauter à la ligne suivante après la lecture
    while (fread(&tempChar, sizeof(char), 1, stdin) == 1 && tempChar != '\n');

    // Allouer de la mémoire pour les données de la piste
    track->trackData = calloc(track->sectionHeight, sizeof(char *));
    for (int i = 0; i < track->sectionHeight; i++) {
        track->trackData[i] = calloc(track->sectionWidth, sizeof(char)); // Allouer de la mémoire pour chaque ligne
        int colIndex = 0;
        while (fread(&tempChar, sizeof(char), 1, stdin) == 1 && tempChar != '\n') {
            track->trackData[i][colIndex] = tempChar; // Lire chaque caractère de la ligne
            colIndex++;
        }
    }

    remainingFuel = track->fuelAmount; // Initialiser le carburant restant

    do {
        lapCounter++; // Compter les tours
        // Lire les coordonnées des obstacles et de la position de départ
        result = fscanf(stdin, "%d %d\t%d %d\t%d %d", &(startTile.y), &(startTile.x), &(obstacleB.y), &(obstacleB.x), &(obstacleC.y), &(obstacleC.x));
        if (lapCounter == 1 || startTile.x != nextTile.x || startTile.y != nextTile.y) {
            collisionFlag = 1; // Si c'est le premier tour ou si la position a changé, marquer une collision
        } else {
            startTile = nextTile; // Mettre à jour la position de départ
            nextTile = dequeue(pathQueue); // Dépiler la prochaine position de la file d'attente
            collisionFlag = 0; // Pas de collision
        }
        isBlocked = (nextTile.x == obstacleB.x && nextTile.y == obstacleB.y) || (nextTile.x == obstacleC.x && nextTile.y == obstacleC.y); // Vérifier si la prochaine position est bloquée par un obstacle

        if (collisionFlag || isBlocked || fuelReductionFlag || fuelIncreaseFlag) {
            // Ajuster le facteur de pondération en fonction des drapeaux de réduction ou d'augmentation de carburant
            if (fuelReductionFlag) {
                upperBound = weightFactor;
                weightFactor = (lowerBound + upperBound) / 2;
            } else if (fuelIncreaseFlag) {
                lowerBound = weightFactor;
                weightFactor = (lowerBound + upperBound) / 2;
            } else if (lapCounter > 1) {
                lowerBound = 0;
                weightFactor = (lowerBound + upperBound) / 2;
            }

            // Sauvegarder les données de la piste et les réinitialiser
            backupCharB = track->trackData[obstacleB.x][obstacleB.y];
            backupCharC = track->trackData[obstacleC.x][obstacleC.y];
            track->trackData[obstacleB.x][obstacleB.y] = '.';
            track->trackData[obstacleC.x][obstacleC.y] = '.';

            if (collisionFlag == 1) {
                startTile.vx = 0; // Réinitialiser la vitesse en cas de collision
                startTile.vy = 0;
            }
            if (lapCounter > 1) {
                freegraph(adjList, track); // Libérer la mémoire de la liste d'adjacence précédente
            }
            adjList = initgraph(track); // Initialiser une nouvelle liste d'adjacence

            int squaredSpeed, accelerationX, accelerationY, fuelCost;
            int finishCounter = 0;
            Tile currentTile, neighborTile;
            Queue *tileQueue = createQueue(); // Créer une file d'attente pour les tuiles
            enqueue(tileQueue, startTile, 1); // Ajouter la tuile de départ à la file d'attente

            while (!isQueueEmpty(tileQueue)) {
                currentTile = dequeue(tileQueue); // Dépiler la tuile actuelle
                adjList->nodeList[currentTile.x][currentTile.y][currentTile.vx + 5][currentTile.vy + 5]->nodeTag = 2;
                adjList->numNodes++; // Incrémenter le nombre de nœuds

                for (accelerationX = -1; accelerationX <= 1; accelerationX++) { // Boucler sur les valeurs possibles d'accélération en x
                    for (accelerationY = -1; accelerationY <= 1; accelerationY++) { // Boucler sur les valeurs possibles d'accélération en y
                        neighborTile.vx = currentTile.vx + accelerationX;
                        neighborTile.vy = currentTile.vy + accelerationY;
                        neighborTile.x = currentTile.x + neighborTile.vx;
                        neighborTile.y = currentTile.y + neighborTile.vy;

                        squaredSpeed = neighborTile.vx * neighborTile.vx + neighborTile.vy * neighborTile.vy;
                        fuelCost = accelerationX * accelerationX + accelerationY * accelerationY + (int)(sqrt(neighborTile.vx * neighborTile.vx + neighborTile.vy * neighborTile.vy) * 1.5);
                        fuelCost += testPoint(track, currentTile, '~'); // Ajouter le coût de carburant pour rouler sur du sable

                        if (TileInTrack(neighborTile, adjList) && squaredSpeed <= 25 && isPathClear(track, currentTile, neighborTile) &&
                            (!testPoint(track, currentTile, '~') || squaredSpeed <= 1)) {
                            if ((testPoint(track, neighborTile, '#') || testPoint(track, neighborTile, '~')) && adjList->nodeList[neighborTile.x][neighborTile.y][neighborTile.vx + 5][neighborTile.vy + 5]->nodeTag != 2) {
                                if (adjList->nodeList[neighborTile.x][neighborTile.y][neighborTile.vx + 5][neighborTile.vy + 5]->nodeTag == 0) {
                                    enqueue(tileQueue, neighborTile, 1); // Ajouter la tuile voisine à la file d'attente
                                    adjList->nodeList[neighborTile.x][neighborTile.y][neighborTile.vx + 5][neighborTile.vy + 5]->nodeTag = 1;
                                }
                                // Créer une nouvelle cellule de connexion
                                Cell *newCell = createCell(neighborTile, fuelCost, accelerationX, accelerationY, adjList->nodeList[currentTile.x][currentTile.y][currentTile.vx + 5][currentTile.vy + 5]->nextCell);
                                adjList->nodeList[currentTile.x][currentTile.y][currentTile.vx + 5][currentTile.vy + 5]->nextCell = newCell;

                                newCell = createCell(currentTile, fuelCost, accelerationX, accelerationY, adjList->nodeList[neighborTile.x][neighborTile.y][neighborTile.vx + 5][neighborTile.vy + 5]->previousCell);
                                adjList->nodeList[neighborTile.x][neighborTile.y][neighborTile.vx + 5][neighborTile.vy + 5]->previousCell = newCell;

                                adjList->numArcs++; // Incrémenter le nombre d'arcs
                            } else if (testPoint(track, neighborTile, '=')) {
                                // Créer une nouvelle cellule de connexion pour une tuile de fin
                                Cell *newCell = createCell(neighborTile, fuelCost, accelerationX, accelerationY, adjList->nodeList[currentTile.x][currentTile.y][currentTile.vx + 5][currentTile.vy + 5]->nextCell);
                                adjList->nodeList[currentTile.x][currentTile.y][currentTile.vx + 5][currentTile.vy + 5]->nextCell = newCell;

                                newCell = createCell(currentTile, fuelCost, accelerationX, accelerationY, adjList->nodeList[neighborTile.x][neighborTile.y][neighborTile.vx + 5][neighborTile.vy + 5]->previousCell);
                                adjList->nodeList[neighborTile.x][neighborTile.y][neighborTile.vx + 5][neighborTile.vy + 5]->previousCell = newCell;

                                adjList->numArcs++;
                                adjList->finishPoints[finishCounter] = neighborTile; // Ajouter la tuile de fin à la liste des points de fin
                                finishCounter++;
                            }
                        } else {
                            neighborTile = currentTile; // Si la tuile voisine n'est pas valide, rester sur la tuile actuelle
                            neighborTile.vx = 0;
                            neighborTile.vy = 0;
                            if (adjList->nodeList[neighborTile.x][neighborTile.y][neighborTile.vx + 5][neighborTile.vy + 5]->nodeTag == 0) {
                                enqueue(tileQueue, neighborTile, 1); // Ajouter la tuile actuelle à la file d'attente
                                adjList->nodeList[neighborTile.x][neighborTile.y][neighborTile.vx + 5][neighborTile.vy + 5]->nodeTag = 1;
                            }
                            // Créer une nouvelle cellule de connexion pour la tuile actuelle
                            Cell *newCell = createCell(neighborTile, fuelCost, accelerationX, accelerationY, adjList->nodeList[currentTile.x][currentTile.y][currentTile.vx + 5][currentTile.vy + 5]->nextCell);
                            adjList->nodeList[currentTile.x][currentTile.y][currentTile.vx + 5][currentTile.vy + 5]->nextCell = newCell;

                            newCell = createCell(currentTile, fuelCost, accelerationX, accelerationY, adjList->nodeList[neighborTile.x][neighborTile.y][neighborTile.vx + 5][neighborTile.vy + 5]->previousCell);
                            adjList->nodeList[neighborTile.x][neighborTile.y][neighborTile.vx + 5][neighborTile.vy + 5]->previousCell = newCell;

                            adjList->numArcs++;
                        }
                    }
                }
            }
            adjList->numFinishPoints = finishCounter;
            if (finishCounter == 0) {
                printf("Error: Finish line not reached!\n");
                return -1; // Quitter si la ligne d'arrivée n'est pas atteinte
            }

            targetTile = dijkstra(adjList, track, startTile, weightFactor); // Exécuter l'algorithme de Dijkstra pour trouver le chemin optimal

            // Trouver le chemin
            pathQueue = createQueue(); // Créer une nouvelle file d'attente pour le chemin
            Tile pathTile = targetTile;
            Cell *currentCell;
            do {
                enqueue(pathQueue, pathTile, 0); // Ajouter la tuile actuelle à la file d'attente du chemin
                currentCell = (adjList->nodeList[pathTile.x][pathTile.y][pathTile.vx + 5][pathTile.vy + 5]->dijPreviousCell);
                pathTile = currentCell->cellLocation; // Passer à la tuile précédente
            } while ((adjList->nodeList[pathTile.x][pathTile.y][pathTile.vx + 5][pathTile.vy + 5]->nodeTotalFuel) != 0);
            enqueue(pathQueue, pathTile, 0); // Ajouter la tuile de départ à la file d'attente du chemin

            fuelReductionFlag = ((float)(adjList->nodeList[targetTile.x][targetTile.y][targetTile.vx + 5][targetTile.vy + 5]->nodeTotalFuel)) > lowerThreshold * ((float)remainingFuel); // Mettre à jour le drapeau de réduction de carburant
            fuelIncreaseFlag = ((float)(adjList->nodeList[targetTile.x][targetTile.y][targetTile.vx + 5][targetTile.vy + 5]->nodeTotalFuel)) < upperThreshold * ((float)remainingFuel); // Mettre à jour le drapeau d'augmentation de carburant

            startTile = dequeue(pathQueue); // Dépiler la prochaine position de la file d'attente du chemin
            nextTile = dequeue(pathQueue); // Dépiler la suivante

            // Restaurer les obstacles sauvegardés
            track->trackData[obstacleB.x][obstacleB.y] = backupCharB;
            track->trackData[obstacleC.x][obstacleC.y] = backupCharC;
        }
        accY = nextTile.vx - startTile.vx; // Calculer l'accélération en y
        accX = nextTile.vy - startTile.vy; // Calculer l'accélération en x

        // Calculer et envoyer la commande d'accélération
        remainingFuel += calculateFuelCost(accX, accY, startTile.vx, startTile.vy, testPoint(track, startTile, '~')); // Mettre à jour le carburant restant
        sendAccelerationCommand(accX, accY); // Envoyer la commande d'accélération

    } while (!feof(stdin)); // Répéter jusqu'à la fin du fichier d'entrée

    return result; // Retourner le résultat final
}
