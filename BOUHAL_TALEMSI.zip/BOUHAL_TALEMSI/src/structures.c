/* -*- c-basic-offset: 3 -*-
 *
 * ENSICAEN
 * 6 Boulevard Marechal Juin
 * F-14050 Caen Cedex
 *
 * This file is owned by ENSICAEN students.
 * 
 */

/**
 * @author BOUHAL Mohamed <mohamed.bouhal@ecole.ensicaen.fr>
 * @author TALEMSI Saad <saad.talemsi@ecole.ensicaen.fr>
 * @version 1.0.0 / 23-05-2024
 */

/**
 * @file structures.c
 */

#include "structures.h"


