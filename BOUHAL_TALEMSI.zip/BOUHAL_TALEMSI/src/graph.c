/* -*- c-basic-offset: 3 -*-
 *
 * ENSICAEN
 * 6 Boulevard Marechal Juin
 * F-14050 Caen Cedex
 *
 * This file is owned by ENSICAEN students.
 * 
 */

/**
 * @author BOUHAL Mohamed <mohamed.bouhal@ecole.ensicaen.fr>
 * @author TALEMSI Saad <saad.talemsi@ecole.ensicaen.fr>
 * @version 1.0.0 / 23-05-2024
 */
/**
 * @file graph.c
 */
#include "math.h"
#include "graph.h"
#include "structures.h"
#define INF INT_MAX
#include <limits.h>

Cell *createCell(Tile location, int fuel, int ax, int ay, Cell *nextCell) {
    Cell *cell = (Cell *) malloc(sizeof(Cell));
    cell->cellLocation = location;
    cell->cellAccelerationX = ax;
    cell->cellAccelerationY = ay;
    cell->cellFuel = fuel;
    cell->nextCell = nextCell;
    return cell;
}

Node *createNode() {
    Node *node = (Node *) malloc(sizeof(Node));
    if(node!= NULL){
    node->nextCell = NULL;
    node->previousCell = NULL;
    node->dijNextCell = NULL;
    node->dijPreviousCell = NULL;
    node->nodeTag = 0;
    node->nodeDistance = -1;
    node->nodeTotalWeight = MAX;
    node->nodeTotalFuel = MAX;
    }
    return node;
}

void freeCells(Cell *cell) {
    if (cell != NULL) {
        freeCells(cell->nextCell);
        free(cell);
    }
}

int TileInTrack(Tile point, graph *L) {
    int x = L->listHeight;
    int y = L->listWidth;
    return (point.x >= 0 && point.y >= 0 && point.x < x && point.y < y);
}

int testPoint(TrackSection track, Tile point, char c) {
    return track->trackData[point.x][point.y] == c;
}

int isPathClear(TrackSection track, Tile startTile, Tile endTile) {
    int index;
    int startX;
    int startY;
    int endX;
    int endY;
    int maxLength;
    float currentX;
    float currentY;
    float deltaX;
    float deltaY;

    startX = startTile.x;
    startY = startTile.y;

    endX = endTile.x;
    endY = endTile.y;

    if (abs(endX - startX) > abs(endY - startY)) {
        maxLength = abs(endX - startX);
    } else {
        maxLength = abs(endY - startY);
    }

    currentX = startX + 0.5f;
    currentY = startY + 0.5f;
    
    deltaX = ((float) (endX - startX)) / maxLength;
    deltaY = ((float) (endY - startY)) / maxLength;

    if (maxLength != 0) {
        for (index = 0; index < maxLength; index++) {
            currentX += deltaX;
            currentY += deltaY;
            startX = (int) currentX;
            startY = (int) currentY;

            if (track->trackData[startX][startY] == '.') {
                return 0; // Chemin bloqué
            }
        }
    }
    return 1; // Chemin dégagé
}

graph *initgraph(TrackSection t) {
    Tile point;
    graph *L = malloc(sizeof(graph));
    L->listHeight = t->sectionHeight;
    L->listWidth = t->sectionWidth;
    L->numArcs = 0;
    L->numNodes = 0;

    for (point.x = 0; point.x < t->sectionHeight; point.x++) {
        for (point.y = 0; point.y < t->sectionWidth; point.y++) {
            // Assuming trackData is still a 2D array of chars
            if (t->trackData[point.x][point.y] == '1') {
                L->startingPoints[0] = point;
            } else if (t->trackData[point.x][point.y] == '2') {
                L->startingPoints[1] = point;
            } else if (t->trackData[point.x][point.y] == '3') {
                L->startingPoints[2] = point;
            }
        }
    }

    // Initialize nodes with zero velocity
    for (point.x = 0; point.x < 3; point.x++) {
        L->startingPoints[point.x].vx = 0;
        L->startingPoints[point.x].vy = 0;
    }

    L->nodeList = (Node*****) malloc(t->sectionHeight * sizeof(Node****));
    for (point.x = 0; point.x < t->sectionHeight; point.x++) {
        L->nodeList[point.x] = (Node****) malloc(t->sectionWidth * sizeof(Node***));
        for (point.y = 0; point.y < t->sectionWidth; point.y++) {
            L->nodeList[point.x][point.y] = (Node***) malloc(11 * sizeof(Node**));
            for (point.vx = 0; point.vx < 11; point.vx++) {
                L->nodeList[point.x][point.y][point.vx] = (Node**) calloc(11, sizeof(Node*));
                for (point.vy = 0; point.vy < 11; point.vy++) {
                    L->nodeList[point.x][point.y][point.vx][point.vy] = createNode();
                }
            }
        }
    }
    return L;
}

void freegraph(graph *L, TrackSection t) {
    Tile point;
    for (point.x = 0; point.x < t->sectionHeight; point.x++) {
        for (point.y = 0; point.y < t->sectionWidth; point.y++) {
            for (point.vx = 0; point.vx < 11; point.vx++) {
                for (point.vy = 0; point.vy < 11; point.vy++) {
                    freeCells(L->nodeList[point.x][point.y][point.vx][point.vy]->dijPreviousCell);
                    freeCells(L->nodeList[point.x][point.y][point.vx][point.vy]->dijNextCell);
                    freeCells(L->nodeList[point.x][point.y][point.vx][point.vy]->previousCell);
                    freeCells(L->nodeList[point.x][point.y][point.vx][point.vy]->nextCell);
                    free(L->nodeList[point.x][point.y][point.vx][point.vy]);
                }
                free(L->nodeList[point.x][point.y][point.vx]);
            }
            free(L->nodeList[point.x][point.y]);
        }
        free(L->nodeList[point.x]);
    }
    free(L->nodeList);
}


/**
 * @brief Implémentation de l'algorithme de Dijkstra pour trouver le chemin optimal sur la piste.
 * 
 * Cette fonction utilise une file de priorité (implémentée comme un arbre de recherche binaire) pour explorer
 * le chemin le moins coûteux depuis la tuile de départ jusqu'à la ligne d'arrivée.
 * 
 * @param network Le graphe représentant la piste avec les nœuds et les connexions.
 * @param trackSection Les données de la section de la piste incluant la disposition et les propriétés.
 * @param startTile La position initiale et la vitesse de la voiture.
 * @param weightFactor Un facteur utilisé pour équilibrer entre la consommation de carburant et la distance.
 * @return Tile La dernière tuile traitée, utile pour tracer le chemin ou pour un traitement ultérieur.
 */
Tile dijkstra(graph *network, TrackSection trackSection, Tile startTile, float weightFactor) {
    // Variables pour gérer les poids et la consommation de carburant
    int weightCalculation;
    int *currentFuel, *nextFuel;
    int *currentWeight, *nextWeight;
    Tile nextTile;
    Cell *cellPointer;
    bst *priorityTree = NULL;

    // Initialiser l'arbre de priorité avec la tuile de départ, en définissant les conditions initiales
    priorityTree = addToBST(priorityTree, 0, startTile);
    network->nodeList[startTile.x][startTile.y][startTile.vx + 5][startTile.vy + 5]->nodeTotalFuel = 0;
    network->nodeList[startTile.x][startTile.y][startTile.vx + 5][startTile.vy + 5]->nodeTotalWeight = 0;

    // Continuer à traiter les nœuds jusqu'à atteindre la ligne d'arrivée
    while (trackSection->trackData[startTile.x][startTile.y] != '=') {
        // Extraire la tuile de poids minimal de l'arbre de priorité
        do {
            priorityTree = popMin(priorityTree, &startTile);
        } while (network->nodeList[startTile.x][startTile.y][startTile.vx + 5][startTile.vy + 5]->nodeTag == 4);

        // Marquer le nœud actuel comme traité
        network->nodeList[startTile.x][startTile.y][startTile.vx + 5][startTile.vy + 5]->nodeTag = 4;

        // Obtenir des pointeurs vers le carburant et le poids du nœud actuel
        currentFuel = &(network->nodeList[startTile.x][startTile.y][startTile.vx + 5][startTile.vy + 5]->nodeTotalFuel);
        currentWeight = &(network->nodeList[startTile.x][startTile.y][startTile.vx + 5][startTile.vy + 5]->nodeTotalWeight);

        // Explorer toutes les cellules adjacentes
        cellPointer = network->nodeList[startTile.x][startTile.y][startTile.vx + 5][startTile.vy + 5]->nextCell;
        while (cellPointer != NULL) {
            nextTile = cellPointer->cellLocation;

            // Sauter les nœuds déjà traités
            if (network->nodeList[nextTile.x][nextTile.y][nextTile.vx + 5][nextTile.vy + 5]->nodeTag != 4) {
                nextFuel = &(network->nodeList[nextTile.x][nextTile.y][nextTile.vx + 5][nextTile.vy + 5]->nodeTotalFuel);
                nextWeight = &(network->nodeList[nextTile.x][nextTile.y][nextTile.vx + 5][nextTile.vy + 5]->nodeTotalWeight);

                // Calculer le nouveau poids pour ce chemin
                weightCalculation = 1000 * cellPointer->cellFuel + (int)(1000 * weightFactor);

                // Si ce chemin est meilleur, mettre à jour le poids et le carburant du nœud
                if ((*currentWeight + weightCalculation) < *nextWeight) {
                    *nextFuel = *currentFuel + cellPointer->cellFuel;
                    *nextWeight = *currentWeight + weightCalculation;

                    // Mettre à jour l'état du nœud et l'ajouter à l'arbre de priorité
                    if (network->nodeList[nextTile.x][nextTile.y][nextTile.vx + 5][nextTile.vy + 5]->nodeTag < 3) {
                        network->nodeList[nextTile.x][nextTile.y][nextTile.vx + 5][nextTile.vy + 5]->nodeTag = 3;
                        priorityTree = addToBST(priorityTree, *nextWeight, nextTile);

                        // Créer de nouvelles cellules pour le suivi du chemin
                        Cell *newCell = createCell(nextTile, cellPointer->cellFuel, cellPointer->cellAccelerationX, cellPointer->cellAccelerationY, 
                                                   network->nodeList[startTile.x][startTile.y][startTile.vx + 5][startTile.vy + 5]->dijNextCell);
                        network->nodeList[startTile.x][startTile.y][startTile.vx + 5][startTile.vy + 5]->dijNextCell = newCell;

                        free(network->nodeList[nextTile.x][nextTile.y][nextTile.vx + 5][nextTile.vy + 5]->dijPreviousCell);
                        network->nodeList[nextTile.x][nextTile.y][nextTile.vx + 5][nextTile.vy + 5]->dijPreviousCell = createCell(startTile, cellPointer->cellFuel, 
                                                                                                                                cellPointer->cellAccelerationX, cellPointer->cellAccelerationY, NULL);
                    } else if (network->nodeList[nextTile.x][nextTile.y][nextTile.vx + 5][nextTile.vy + 5]->nodeTag == 3) {
                        priorityTree = addToBST(priorityTree, *nextWeight, nextTile);

                        Cell *newCell = createCell(nextTile, cellPointer->cellFuel, cellPointer->cellAccelerationX, cellPointer->cellAccelerationY, 
                                                   network->nodeList[startTile.x][startTile.y][startTile.vx + 5][startTile.vy + 5]->dijNextCell);
                        network->nodeList[startTile.x][startTile.y][startTile.vx + 5][startTile.vy + 5]->dijNextCell = newCell;

                        free(network->nodeList[nextTile.x][nextTile.y][nextTile.vx + 5][nextTile.vy + 5]->dijPreviousCell);
                        network->nodeList[nextTile.x][nextTile.y][nextTile.vx + 5][nextTile.vy + 5]->dijPreviousCell = createCell(startTile, cellPointer->cellFuel, 
                                                                                                                                cellPointer->cellAccelerationX, cellPointer->cellAccelerationY, NULL);
                    }
                }
            }
            // Passer à la cellule suivante
            cellPointer = cellPointer->nextCell;
        }
    }
    return startTile;  // Retourner la dernière tuile traitée, potentiellement utile pour un traitement ultérieur
}










